const gulp = require('gulp');
const sourcemaps = require('gulp-sourcemaps');
const runSequence = require('run-sequence');
const conf = require('../gulpconfig');
const autoprefixer = require('gulp-autoprefixer');
const sass = require('gulp-sass');

gulp.task('js:dev', function () {
    console.log('Copying JS to: ' + conf.path.dest.base);
    return gulp.src(conf.path.src.js)
        .pipe(sourcemaps.init())
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(conf.path.dest.js));
});

gulp.task('css:compile:dev', function () {
    console.log('CSS from ' + conf.path.src.scss);
    console.log('CSS to ' + conf.path.dest.css);
    return gulp.src([conf.path.src.scss + '/*.{scss,sass}'])
        .pipe(sourcemaps.init())
        .pipe(sass().on('error', sass.logError))
        .pipe(autoprefixer({
            browsers: ['last 2 versions']
        }))
        .pipe(sourcemaps.write())
        .pipe(gulp.dest(conf.path.dest.css));
});

gulp.task('reload', ['html', 'images', 'js:dev'], function() {
    return global.browserSync.reload('*');
});

gulp.task('css:watch', ['css:compile:dev'], function () {
    return global.browserSync.reload('*.css');
});

gulp.task('watch', ['browser-sync'], function() {
    gulp.watch(conf.path.src.scss + '/**/*.scss', ['css:watch']);
    gulp.watch(conf.path.src.base + '/*.html', ['reload']);
    gulp.watch(conf.path.src.base + '/images', ['reload']);
    gulp.watch(conf.path.src.base + '/js', ['reload']);
});

gulp.task('development', function (callback) {
    console.log('Building files');
    runSequence(
        'clean',
        'sprite',
        ['css:compile:dev', 'js:dev', `images`],
        'html',
        'watch',
        callback
    );
});