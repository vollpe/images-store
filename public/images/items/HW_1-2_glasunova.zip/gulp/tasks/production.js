const gulp = require('gulp');
const uglify = require('gulp-uglify');
const concat = require('gulp-concat');
const runSequence = require('run-sequence');
const conf = require('../gulpconfig');
const autoprefixer = require('gulp-autoprefixer');
const sass = require('gulp-sass');
const csso = require('gulp-csso');

gulp.task('js:minimize:prod', function () {
    console.log('Copying JS to: ' + conf.path.dest.js);
    return gulp.src(conf.path.src.js)
        .pipe(concat('main.min.js'))
        .pipe(uglify())
        .pipe(gulp.dest(conf.path.dest.js))
});

gulp.task('css:compile:prod', function() {
    console.log('CSS from ' + conf.path.src.scss);
    console.log('CSS to ' + conf.path.dest.css);
    return gulp.src([conf.path.src.scss + '/*.{scss,sass}'])
        .pipe(sass().on('error', sass.logError))
        .pipe(autoprefixer({
            browsers: ['last 2 versions']
        }))
        .pipe(csso())
        .pipe(gulp.dest(conf.path.dest.css));
});

gulp.task('compile', function(callback) {
    console.log('Building files');
    runSequence(
        'clean',
        'sprite',
        ['css:compile:prod', 'js:minimize:prod', `images`],
        'html',
        callback
    );
});

gulp.task('production', function(callback) {
    console.log('Building files');
    runSequence(
        'compile',
        'browser-sync',
        callback
    );
});
