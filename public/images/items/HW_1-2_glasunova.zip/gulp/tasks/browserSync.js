const gulp = require('gulp');

const conf = require('../gulpconfig');

gulp.task('browser-sync', function() {
    return global.browserSync.init({
        server: {
            baseDir: conf.path.dest.base,
        },
        injectchanges: true,
    });
});