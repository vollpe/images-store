const src = 'src';
const dest = 'dist';

module.exports = {
    path: {
        src: {
            base: src,
            scss: src + '/styles',
            images: src + '/images/*',
            svg: src + '/images/svg',
            js: src + '/js/*'
        },
        dest: {
            base: dest,
            css: dest + '/styles',
            images: dest + '/images',
            svg: dest + '/images/svg',
            js: dest + '/js'
        }
    }
};