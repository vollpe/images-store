document.getElementById('hide').addEventListener('click', function() {
    // hide element by click
    document.getElementById('sample').style.display='none';
});