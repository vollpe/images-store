const gulp = require('gulp');
const requireDir = require('require-dir');
const browserSync = require('browser-sync').create();
const conf = require('./gulp/gulpconfig');
const inject = require('gulp-inject');
const del = require('del');

global.browserSync = browserSync;

requireDir('./gulp/tasks', {recurse: false});

gulp.task('default', ['watch']);
gulp.task('clean', ['clean:dist']);
gulp.task('dev', ['development']);
gulp.task('prod', ['production']);
gulp.task('sprite', ['sprite:build']);

// Common tasks
gulp.task('images', function () {
    console.log('Copying images to: ' + conf.path.dest.base);
    return gulp.src(conf.path.src.images)
        .pipe(gulp.dest(conf.path.dest.images));
});

gulp.task('html', function () {
    var sources = gulp.src(['js/*.js', 'styles/*.css'], {read: false, cwd: conf.path.dest.base});
    return gulp.src(conf.path.src.base + '/index.html')
        .pipe(inject(sources, {relative: true, ignorePath: '../dist/'}))
        .pipe(gulp.dest(conf.path.dest.base));
});

gulp.task('clean:dist', function () {
    console.log('Cleaning: ' + conf.path.dest.base);
    return del.sync(conf.path.dest.base + '/*');
});
